#include <iostream>
using namespace std;
int main() {
    int purchases[5];
    int evenTotal = 0;
    cout << "Enter five purchase amounts:\n";
    for (int i = 0; i < 5; ++i) {
        cout << "Enter purchase amount " << (i + 1) << "=";
        cin >> purchases[i];
    }

    int evenCount = 0;
    int oddCount = 0;
    for (int i = 0; i < 5; ++i) {
        if (purchases[i] % 2 == 0) {
            evenCount++;
            evenTotal += purchases[i];
        } else {
            oddCount++;
        }
    }
    cout << "Distribution of purchases:"<<endl;
    cout << "Even purchases: " << evenCount <<endl;
    cout << "Odd purchases: " << oddCount <<endl;
    cout << "Total amount spent on even-numbered purchases: " << evenTotal <<endl;

    return 0;
}
