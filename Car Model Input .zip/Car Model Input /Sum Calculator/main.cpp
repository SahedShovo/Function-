#include <iostream>
#include<string>
using namespace std;
class Car{
private:
    string Company;
    string Model;
    int Year;
public:
    void setcompany(string comp){
        Company=comp;
    }
    void setmodel(string mod){
        Model=mod;
    }
    void setyear(int year){
        Year=year;
    }
    string getcompany(){
            return Company;
        }
        string getmodel(){
            return Model;
        }
    int getyear(){
        return Year;
    }
};
int main(){
    Car MyCar;
    MyCar.setcompany("Red Davil");
    MyCar.setmodel("Dodge");
    MyCar.setyear(2023);
    cout << "Car Company: " << MyCar.getcompany() << endl;
    cout << "Car Model: " << MyCar.getmodel() << endl;
    cout << "Car Year: " << MyCar.getyear() << endl;
}
