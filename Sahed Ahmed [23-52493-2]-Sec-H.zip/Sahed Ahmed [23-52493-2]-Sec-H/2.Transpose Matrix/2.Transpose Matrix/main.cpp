#include <iostream>
using namespace std;
int main() {
    int row, col;
    cout << "Enter the number of rows : ";
    cin >> row;
    cout << "Enter the number of columns : ";
    cin >> col;
    int matrix[row][col];
    cout << "Enter the elements of the matrix:" <<endl;
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            cout << "Enter element at position [" << i << "][" << j << "]: ";
            cin >> matrix[i][j];
        }
    }

    cout << "\nOriginal Matrix:" << endl;
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            cout << matrix[i][j] << "\t";
        }
        cout << endl;
    }

    cout << "\nTranspose Matrix:" << endl;
    for (int i = 0; i < col; ++i) {
        for (int j = 0; j < row; ++j) {
            cout << matrix[j][i] << "\t";
        }
        cout <<endl;
    }

    return 0;
}

