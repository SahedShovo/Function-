#include <iostream>
#include <string>
using namespace std;
const int NumberCountries = 5;
const int CountryLength = 50;

int main() {
   string countries[ NumberCountries];

    cout << "Enter the names of " <<  NumberCountries << " countries" << endl;
    for (int i = 0; i < NumberCountries; ++i) {
        cout << "Enter country " << i + 1 << "=";
        getline(cin, countries[i]);
    }

    cout << "\nCountries entered:\n";
    for (int i = 0; i <  NumberCountries; ++i) {
        cout << "Country " << i + 1 << "=" << countries[i] << endl;
    }

    return 0;
}
