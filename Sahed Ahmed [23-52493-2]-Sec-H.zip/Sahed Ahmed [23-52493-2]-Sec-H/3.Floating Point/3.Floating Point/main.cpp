#include <iostream>
#include <limits>
using namespace std;
const int Row = 2;
const int Col= 4;

int main() {
    float matrix[Row][Col];
    cout << "Enter " << Row * Col << " floating-point numbers :" <<endl;
    for (int i = 0; i < Row; ++i) {
        for (int j = 0; j < Col; ++j) {
            cout << "Enter element = [" << i << "][" << j << "]= ";
            cin >> matrix[i][j];
        }
    }
    float largestFirstRow = matrix[0][0];
    for (int j = 1; j < Col; ++j) {
        if (matrix[0][j] > largestFirstRow) {
            largestFirstRow = matrix[0][j];
        }
    }
    float smallestSecondRow = matrix[1][0];
    for (int j = 1; j < Col; ++j) {
        if (matrix[1][j] < smallestSecondRow) {
            smallestSecondRow = matrix[1][j];
        }
    }
    float multipliedResult = largestFirstRow * smallestSecondRow;
    cout << "\nLargest element in the first row: " << largestFirstRow << endl;
    cout << "Smallest element in the second row: " << smallestSecondRow <<endl;
    cout << "Multiplied result: " << multipliedResult <<endl;

    return 0;
}

