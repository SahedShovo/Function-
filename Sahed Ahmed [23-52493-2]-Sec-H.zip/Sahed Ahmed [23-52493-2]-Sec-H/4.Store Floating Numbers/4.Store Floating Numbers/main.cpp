#include <iostream>
using namespace std;
const int Row = 3;
const int Col = 3;

int main() {
    float matrix[Row][Col];
    cout << "Enter " << Row * Col << " floating-point numbers for the " << Row << "x" << Col << " matrix:" <<endl;
    for (int i = 0; i <Row; ++i) {
        for (int j = 0; j <Col; ++j) {
            cout << "Enter element at position [" << i << "][" << j << "]= ";
            cin >> matrix[i][j];
        }
    }
    float numberToSearch;
    cout << "Enter a number to search in the array: ";
    cin >> numberToSearch;
    bool found = false;
    for (int i = 0; i <Row; ++i) {
        for (int j = 0; j <Col; ++j) {
            if (matrix[i][j] == numberToSearch) {
                found = true;
                break;
            }
        }
        if (found) {
            break;
        }
    }
    if (found) {
    cout << "The number " << numberToSearch << " is present in the array." <<endl;
    } else {
        cout << "The number " << numberToSearch << " is not present in the array." <<endl;
    }

    return 0;
}

